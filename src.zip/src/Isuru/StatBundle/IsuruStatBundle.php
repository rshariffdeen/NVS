<?php

namespace Isuru\StatBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IsuruStatBundle extends Bundle
{
}
