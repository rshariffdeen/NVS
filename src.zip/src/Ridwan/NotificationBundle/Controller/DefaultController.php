<?php

namespace Ridwan\NotificationBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        $message = \Swift_Message::newInstance()
                ->setSubject('Volma Registration')
                ->setFrom('Moraspirit@gmail.com')
                ->setTo('rshariffdeen@gmail.com')
                ->setBody("TESTING" , 'text/html'
                )
        ;
        $this->get('mailer')->send($message);
        return true;
    }
}