<?php

namespace Ridwan\EntityBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RidwanEntityBundle extends Bundle
{
}
